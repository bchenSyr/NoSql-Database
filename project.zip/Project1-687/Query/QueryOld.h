#pragma once
/////////////////////////////////////////////////////////////////////
// Queries.h - retrieve NoSqlDb contents                           //
// ver 1.0                                                         //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2017       //
/////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* This package defines a single class, Query that provides an execute(...)
* to execute a query callable object.  It also defines a type for 
* callable object queries that return keysets.
*
* You can construct queries that simply modify or examing the NoSqlDb
* without returning meaningful keys.  In this case, the caller simply
* ignores the returned keysets.
*
* Required Files:
* ---------------
*   Queries.h, Queries.cpp,
*   NoSqlDb.h, NoSqlDb.cpp,
*   Utilities.h, Utilities.cpp,
*   Display.h, Display.cpp (only if you enable the test stub)
*
* Maintenance History:
*---------------------
* ver 2.0 : 22 Feb 2017
* - reduced the number of query types to one, with no loss of
*   generality
* ver 1.0 : 06 Feb 2017
* - first release
*/

#include "DbCore.h"
#include "../Utilities/StringUtilities/StringUtilities.h"
#include <functional>
#include <string>
#include <vector>
#include <iostream>
#include <regex>

using namespace std;

namespace NoSqlDb
{
	///////////////////////////////////////////////////////////////////
	// Query class defines a single type of "query" function.
	// - The Query function accepts a const std::string& and a set of keys
	//   and returns a different set of keys, to support compound queries.
	//
	// - Query accepts a database reference and uses that to make
	//   all its queries.
	// - I plan to replace the reference with a std::shared_ptr so that
	//   the database can be changed without making a new instance of
	//   Query class.
	//
	template<typename T>
	class Query
	{
	public:
		using Arg = string;
		using QueryType = std::function<Keys(const Arg&, const Keys& keys)>;

		Query(DbCore<T>& db) : pDb_(&db) {}

		void setDbPointer(DbCore<T>* pDb) { pDb_ = pDb; }

		Keys execute(QueryType q, const Arg& arg, const Keys& keys);

		DbCore<T>& database() { return *pDb_; }

	private:
		DbCore<T>* pDb_;
	};
	
	//----< returns keyset of elements that match query >----------------
	template<typename T>
	Keys Query<T>::execute(QueryType q, const Arg& arg, const Keys& keys)
	{
		return q(arg, keys);
	}

	///////////////////////////////////////////////////////////////////
	// TestQueries class used to test and demonstrate queries
	// of several different types in TestExecutive
	template<typename T>
	class TestQueries
	{
	public:
		TestQueries(std::ostream& out) : out_(out) {};
		void doQueries(DbCore<T>& db);

	private:
		DbCore<T>* pDb = nullptr;
		std::ostream& out_;
		void TestQuery1(const std::string& arg);
		//void TestQuery2(const std::string& arg);
		//void TestQuery3(const std::string& arg);
		//void TestQuery4(const std::string& arg);
		//void TestQuery5(const std::string& arg);
		//void TestQuery6(const std::string& arg);
		//void TestQuery7(DateTime dt1, DateTime dt2);
	};

	//----< run all query tests >-------------------------------------
	template<typename T>
	void TestQueries<T>::doQueries(DbCore<T>& db)
	{
		pDb = &db;
		Utilities::title("Testing Required Queries");
		showDb(db);

		TestQuery1("Potter");
		//TestQuery2("elem1");
		//std::string regEx = ".*2.*";
		//TestQuery3(regEx);
		//regEx = ".*el.*";
		//TestQuery4(regEx);
		//regEx = "test";
		//TestQuery5(regEx);
		//regEx = ".*(2'|3').*";
		//TestQuery6(regEx);
		//DateTime dt = DateTime().now();
		//DateTime::Duration dur = DateTime::makeDuration(1,0,0,0);
		//TestQuery7(dt + dur, dt - dur);
	}

	//----< does key exist? >------------------------------------------
	template<typename T>
	void TestQueries<T>::TestQuery1(const string& arg)
	{
		Query<T>::QueryType getKeyIfExists = [](const string& arg, Keys keys)
		{
			DbCore<T>::Keys returnKeys;
			std::cout << "\n    getKeyIfExists Query for \"" << arg << "\"";
			for (DbCore<T>::Key k : keys)
			{
				if (k == arg)
				{
					returnKeys.push_back(static_cast<string>(k));
					break;
				}
			}
			return returnKeys;
		};

		cout << "\n  results of query #1:";
		Keys keys = pDb->keys();
		keys = getKeyIfExists(arg, keys);
		if (keys.size() == 1)
			std::cout << "\n    found key \"" << arg << "\"";
		else
			std::cout << "\n    didn't find key \"" << arg << "\"";
	}

}
